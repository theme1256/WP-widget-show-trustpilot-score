=== Widget to show a trustpilot score ===
Contributors: folkmann
Tags: trustpilot, widget, trustscore
License: MIT

A widget, that shows the trustpilot rating of a site on trustpilot, like the TrustBox Mini.

== Description ==
It\'s as simple as the short description.
It\'s s widget, that shows the trustpilot rating of a site on trustpilot, like the TrustBox Mini.

It\'s capable of watching multiple sites, because the site is set pr widget.

== Installation ==
1. Drag the widget to the sidebar where it shall be
2. Give it a title (will be written as the title in the shown widget)
3. Give it the site to watch (the part after https://dk.trustpilot.com/review/)
4. Save it and you are done